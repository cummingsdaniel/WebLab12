<?php require_once('customerDAO.php'); ?>
<!DOCTYPE html>
<html>
    <head>
        <title>WP Eatery - Contact Us</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link href='http://fonts.googleapis.com/css?family=Fugaz+One|Muli|Open+Sans:400,700,800' rel='stylesheet' type='text/css' />
        <link href="css/style.css" rel="stylesheet" type="text/css">
    </head>

    <body>
    
        <div id="wrapper">
        <?php include 'header.php'; ?>  
            <div id="content" class="clearfix">
                <aside>
                        <h2>Mailing Address</h2>
                        <h3>1385 Woodroffe Ave<br>
                            Ottawa, ON K4C1A4</h3>
                        <h2>Phone Number</h2>
                        <h3>(613)727-4723</h3>
                        <h2>Fax Number</h2>
                        <h3>(613)555-1212</h3>
                        <h2>Email Address</h2>
                        <h3>info@wpeatery.com</h3>
                </aside>
                <div class="main">
                    <h1>Sign up for our newsletter</h1>
                    <p>Please fill out the following form to be kept up to date with news, specials, and promotions from the WP eatery!</p>
                    <?php
        try{
            $customerDAO = new customerDAO();
            $hasError = false;
            $errorMessages = Array();
            if(isset($_POST['customerName']) || isset($_POST['phoneNumber']) || isset($POST['emailAddress'])){

                if($_POST['customerName'] == ""){
                    $errorMessages['customerNameError'] = "Please enter a customer name.";
                    $hasError = true;
                }

                if($_POST['phoneNumber'] == ""){
                    $errorMessages['phoneNumberError'] = "Please enter a phone number.";
                    $hasError = true;
                }
                if($_POST['emailAddress'] == ""){
                    $errorMessages['emailAddressError'] = "Please enter an email address.";
                     $hasError = true;
                }
                if($_POST['referrer'] == "") {
                    $errorMessages['referrerError'] = "Please enter a referrer";
                    $hasError = true;
                }

                if(!$hasError){
                    $customer = new Customer(0, $_POST['customerName'], $_POST['phoneNumber'], $_POST['emailAddress'], $_POST['referrer']);
                    $addSuccess = $customerDAO->addCustomer($customer);
                    echo '<h3>' . $addSuccess . '</h3>';
                }
            }  
       /*
            if(isset($_GET['deleted'])){
                if($_GET['deleted'] == true){
                    echo '<h3>Customer Deleted</h3>';
                }
            }  */
            
        ?>
                    <form name="addCostomer" id="addCustomer" method="post" action="contact.php">
                        <table>
                            <tr>
                                <td>Name:</td>
                                <td><input type="text" name="customerName" id="customerName" size='40'><?php 
                                if(isset($errorMessages['customerNameError'])){
                                echo '<span style=\'color:red\'>' . $errorMessages['customerNameError'] . '</span>';
                                 }
                                 ?></td>
                            </tr>
                            <tr>
                                <td>Phone Number:</td>
                                <td><input type="text" name="phoneNumber" id="phoneNumber" size='40'><?php 
                                if(isset($errorMessages['phoneNumberError'])){
                                 echo '<span style=\'color:red\'>' . $errorMessages['phoneNumberError'] . '</span>';
                                }
                                 ?></td>
                            </tr>
                            <tr>
                                <td>Email Address:</td>
                                <td><input type="text" name="emailAddress" id="emailAddress" size='40'>
                                <?php 
                                  if(isset($errorMessages['emailAddressError'])){
                                    echo '<span style=\'color:red\'>' . $errorMessages['emailAddressError'] . '</span>';
                                    }
                                    ?>
                                 </td>
                            </tr>
                            <tr>
                                <td>How did you hear<br> about us?</td>
                                <td>Newspaper<input type="radio" name="referrer" id="referrerNewspaper" value="newspaper">
                                    Radio<input type="radio" name='referrer' id='referrerRadio' value='radio'>
                                    TV<input type='radio' name='referrer' id='referrerTV' value='TV'>
                                    Other<input type='radio' name='referrer' id='referrerOther' value='other'>
                                    <?php 
                                    if(isset($errorMessages['referrerError'])){
                                    echo '<span style=\'color:red\'>' . $errorMessages['referrerError'] . '</span>';
                                     }
                                     ?>
                            </tr>
                            <tr>
                                <td colspan='2'><input type='submit' name='btnSubmit' id='btnSubmit' value='Sign up!'>&nbsp;&nbsp;<input type='reset' name="btnReset" id="btnReset" value="Reset Form"></td>
                                <td colspan='2'><input type="file" name="fileSumit" id="fileSubmit" value="Submit File"></td>
                            </tr>
                        </table>
                    </form>
                </div><!-- End Main -->
            </div><!-- End Content -->
        </div><!-- End Wrapper -->
        <?php 
                    }catch(Exception $e){
                        echo '<h3>Error on page.</h3>';
                        echo '<p>' . $e->getMessage() . '</p>';            
                    } 
            ?> 
            <?php include 'footer.php'; ?> 
    </body>
</html>
