<?php
require_once('userDAO.php');
class Users{
    private $AdminID;
    private $Username;
    private $Password;
    private $Lastlogin;

    function __construct($AdminID, $Username, $Password, $Lastlogin){
        $this->setAdminID($AdminID);
        $this->setUsername($Username);
        $this->setPassword($Password);
        $this->setLastlogin($Lastlogin);
    }
    
    public function getAdminID(){
        return $this->AdminID;
    }
    
    public function setAdminID($AdminID){
        $this->AdminID = $AdminID;
    }
    
    public function getUsername(){
        return $this->Username;
    }
    
    public function setUsername($Username){
        $this->Username = $Username;
    }
    
    public function getPassword(){
        return $this->Password;
    }
    
    public function setPassword($Password){
        $this->Password = $Password;
    }
    
    public function getLastlogin() {
        return $this->Lastlogin;
    }

    public function setLastlogin($Lastlogin){
        $this->Lastlogin = $Lastlogin;
    }
    
}
?>