<!DOCTYPE html>
<html>
    <head>
        <title>WP Eatery - Contact Us</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link href='http://fonts.googleapis.com/css?family=Fugaz+One|Muli|Open+Sans:400,700,800' rel='stylesheet' type='text/css' />
        <link href="css/style.css" rel="stylesheet" type="text/css">
    </head>
    <?php 
    include 'header.php';
    ?>
    <?php
    require_once('Users.php');
    require_once('userDAO.php');
    session_start();
    if(isset($_SESSION['Users'])) {
        if($_SESSION['Users']->check()) {
            header('Location:mailing_list.php');
        }
    }
    
    $missingFields = false;
    if(isset($_GET['submit'])){
        if(isset($_GET['User']) && isset($_GET['Password'])){
            if($_GET['User'] == "" || $_GET['Password'] == ""){
                $missingFields = true;
            } else {
                //All fields set, fields have a value
                $userTable = new userDAO();
                    $User = $_GET['User'];
                    $password = $_GET['Password'];
                    $AdminID = $userTable->check($User, $password);
                    if($userTable->isChecked()){
                        $_SESSION['AdminID'] = $AdminID;
                        $userTable->updateDate($User, $password);
                        header('Location:mailing_list.php');
                    }
            }
        }
    }
    ?>
    <form name="logIn" id="logIn" method="get" action="userlogin.php">
    <?php

    ?>
    <table>
    <tr>
    <td>User: </td>
    <td><input type="text" name="User" id="User"></td>
    </tr>
    <tr>
    <td>Password: </td>
    <td><input type="text" name="Password" id="Password"></td>
    </tr>
    <tr>
    <td colspan='2'><input type='submit' name='submit' id='btnlog' value='Sign In'></td>
    </tr>
    </form>
    </html>
