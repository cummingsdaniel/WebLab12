<?php require_once('customerDAO.php'); ?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>WP eatery</title>
        <link href='http://fonts.googleapis.com/css?family=Fugaz+One|Muli|Open+Sans:400,700,800' rel='stylesheet' type='text/css' />
        <link href="css/style.css" rel="stylesheet" type="text/css">
    </head>
    <body>
    <div id="wrapper">
    <?php include 'header.php'; ?>
    

            
       
        <form name="addCustomer" method="post" action="index.php">
        

        </form>
                    
    </body>
</html>