<?php
require_once('abstractDAO.php');
require_once('Users.php');

class userDAO extends abstractDAO {

    private $checked;
    function __construct() {
        try{
            parent::__construct();
        }catch(mysqli_sql_exception $e) {
            throw $e;
        }
    }

    public function updateDate($userCheck, $passCheck) {
        $stmt = $this->mysqli->prepare('UPDATE adminusers SET Lastlogin = CURRENT_DATE WHERE Username = ? AND Password = ?');
        $stmt->bind_param('ss',$userCheck, $passCheck);
        $stmt->execute();
    }

    public function check($userCheck, $passCheck) {
        $stmt = $this->mysqli->prepare('SELECT * FROM adminusers WHERE Username = ? AND Password = ?');
        $stmt->bind_param('ss',$userCheck, $passCheck);
        $stmt->execute();
        $result = $stmt->get_result();
        if($result->num_rows > 0) {
           $temp = $result->fetch_assoc();
            $User = new Users($temp['AdminID'], $temp['Username'], $temp['Password'], $temp['Lastlogin']);
            $result->free();
            $this->checked = true;
            return $User;
           
        }
        $result->free();
        return false;
    }
    public function isChecked() {
        return $this->checked;
    }
    public function hasDbError(){
        
    }
}