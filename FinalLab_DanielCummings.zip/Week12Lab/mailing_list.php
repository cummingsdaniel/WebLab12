<!DOCTYPE html>
<html>
    <head>
        <title>WP Eatery - Contact Us</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link href='http://fonts.googleapis.com/css?family=Fugaz+One|Muli|Open+Sans:400,700,800' rel='stylesheet' type='text/css' />
        <link href="css/style.css" rel="stylesheet" type="text/css">
    </head>
    <?php 

    session_start();
    if(isset($_SESSION['AdminID'])){
    ?>  
    <body>
    <?php include 'header.php'; ?>
<?php require_once('customerDAO.php'); ?>

<?php require_once('customer.php'); ?>
<?php
    $customerDAO = new customerDAO(); 
        $customers = $customerDAO->getCustomers();
            if($customers){
                echo '<table border=\'1\'>';
                echo '<tr><th>Customer ID</th><th>Customer Name</th><th>Phone Number</th><th>Email Address</th></tr>';
                foreach($customers as $customer){
                    echo '<tr>';
                    echo '<td><a href=\'edit_Customer.php?_id='. $customer->get_id() . '\'>' . $customer->get_id() . '</a></td>';
                    echo '<td>' . $customer->getCustomerName() . '</td>';
                    echo '<td>' . $customer->getPhoneNumber() . '</td>';
                    echo '<td>' . $customer->getEmailAddress() . '</td>';
                    echo '<td>' . $customer->getReferrer() . '</td>';
                }
            }
        } else{
            header("Location:userlogin.php");
        }
        ?>
            </body>
</html>