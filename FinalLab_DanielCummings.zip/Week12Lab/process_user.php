<?php
require_once('userDAO.php');
$userDAO = new userDAO();
?>