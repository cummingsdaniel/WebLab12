<?php
require_once('customerDAO.php');
if(isset($_GET['action'])){
    if($_GET['action'] == "edit"){
        if(isset($_POST['_id']) && 
                isset($_POST['customerName']) && 
                isset($_POST['phoneNumber']) &&
                isset($_POST['emailAddress']) &&
                isset($_POST['referrer'])){
        
        if(is_numeric($_POST['_id']) && $_POST['customerName'] != "" && $_POST['phoneNumber'] != "" && $_POST['emailAddress'] != "" && $_POST['referrer'] !=""){    
               
                $customerDAO = new customerDAO();
                $result = $customerDAO->editCustomer($_POST['_id'], 
                        $_POST['customerName'], $_POST['phoneNumber'], $_POST['emailAddress'], $_POST['referrer']);
                

                if($result > 0){
                    header('Location:edit_customer.php?recordsUpdated='.$result.'&_id=' . $_POST['_id']);
                } else {
                    header('Location:edit_customer.php?_id=' . $_POST['_id']);
                }
            } else {
                header('Location:edit_customer.php?missingFields=true&_id=' . $_POST['_id']);
            }
        } else {
            header('Location:edit_customer.php?error=true&_id=' . $_POST['_id']);
        }
    }
    
    if($_GET['action'] == "delete"){
        if(isset($_GET['_id']) && is_numeric($_GET['_id'])){
            $customerDAO = new customerDAO();
            $success = $customerDAO->deleteCustomer($_GET['_id']);
            echo $success;
            if($success){
                header('Location:index.php?deleted=true');
            } else {
                header('Location:index.php?deleted=false');
            }
        }
    }
}
?>
