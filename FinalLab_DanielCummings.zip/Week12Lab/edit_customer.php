<?php
require_once('customerDAO.php');

if(!isset($_GET['_id']) || !is_numeric($_GET['_id'])){
//Send the user back to the main page
header("Location: index.php");
exit;

} else{
    $customerDAO = new customerDAO();
    $customer = $customerDAO->get_Customer($_GET['_id']);
    if($customer){
?>    
        
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Week 10 Lab - Edit Customer - <?php echo $customer->getCustomerName() . ' ' . $customer->getphoneNumber() . ' ' . $customer->getEmailAddress();?></title>
        <script type="text/javascript">
            function confirmDelete(customerInfo){
                return confirm("Do you wish to delete " + customerInfo + "?");
            }
        </script>
    </head>
    <body>
        
        <?php
        if(isset($_GET['recordsUpdated'])){
                if(is_numeric($_GET['recordsUpdated'])){
                    echo '<h3> '. $_GET['recordsUpdated']. ' Customer Record Updated.</h3>';
                }
        }
        if(isset($_GET['missingFields'])){
                if($_GET['missingFields']){
                    echo '<h3 style="color:red;"> Please enter both first and last names.</h3>';
                }
        }?>
        <h3>Edit Customer</h3>
        <form name="editCustomer" method="post" action="process_customer.php?action=edit">
            <table>
                <tr>
                    <td>Customer ID:</td>
                    <td><input type="hidden" name="_id" id="_id" 
                               value="<?php echo $customer->get_id();?>"><?php echo $customer->get_id();?></td>
                </tr>
                <tr>
                    <td>Customer Name:</td>
                    <td><input type="text" name="customerName" id="customerName" 
                               value="<?php echo $customer->getCustomerName();?>"></td>
                </tr>
                <tr>
                    <td>Phone Number:</td>
                    <td><input type="text" name="phoneNumber" id="phoneNumber" 
                               value="<?php echo $customer->getphoneNumber();?>"></td>
                </tr>
                <tr>
                <td>Email Address:</td>
                <td><input type="text" name="emailAddress" id="emailAddress"
                        value="<?php echo $customer->getEmailAddress();?>"></td>
                </tr>
                <tr>
                    <td cospan="2">
                    <a onclick="return confirmDelete('<?php echo $customer->getCustomerName() . ' ' . $customer->getphoneNumber() . ' ' . $customer->getEmailAddress();?>')" href="process_customer.php?action=delete&_id=<?php echo $customer->get_id();?>">DELETE <?php echo $customer->getCustomerName() . " " . $customer->getphoneNumber() . " " . $customer->getEmailAddress();?></a></td>
                </tr>
                <tr>
                    <td><input type="submit" name="btnSubmit" id="btnSubmit" value="Update Customer"></td>
                    <td><input type="reset" name="btnReset" id="btnReset" value="Reset"></td>
                </tr>
            </table>
        </form>
        <h4><a href="index.php">Back to main page</a></h4>
    </body>
</html>
<?php } else{
//Send the user back to the main page
header("Location: index.php");
exit;
}

} ?>